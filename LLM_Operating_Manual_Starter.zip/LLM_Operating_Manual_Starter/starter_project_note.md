# Active Project Starter Note

```yaml
Descriptor:
  Project: <project-name>
  Objective: <1–2 sentences>
  Sources: [<links or file IDs>]
  Output_Type: <memo|csv|python|excel-notes|checklist>
  Style: DDAY_v2.1_simple
Chain_of_Origin:
  Created_By: human
  Derived_From: []
  Date: YYYY-MM-DD
  Status: SYNTH
Evidence_Policy:
  Mode: hybrid
  Notes: []
```

## Session Log
- YYYY-MM-DD: Created. Next: run First-Principles Auditor on <topic>.
