# Week-One Adoption Checklist

- [ ] Add the Descriptor header to 3 active projects.
- [ ] Rename 3 artifacts to the universal pattern.
- [ ] Run First-Principles + MSO on one task.
- [ ] Schedule Backlog Burndown (15–25m) and Weekly Review.
- [ ] Create roles.md and log first bake-off.
- [ ] Define Voice+Screen session SOP (how transcript → SYNTH note).
