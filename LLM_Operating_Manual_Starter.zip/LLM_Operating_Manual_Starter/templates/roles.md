# roles.md — Quarterly Tool Bake-Off

Scoring (1–5): Speed | First-principles accuracy | Structure fidelity | Citation quality | Long-context handling

| Date | Task Archetype | ChatGPT Score | Claude Score | NotebookLM Score | Winner | Notes |
|------|-----------------|---------------|--------------|------------------|--------|-------|
| YYYY-MM-DD | <e.g., Research Extract> |  |  |  |  |  |

**Default Role Map (until next bake-off):**
- Research Extract: <tool>
- Synthesis/Structure: <tool>
- Audit/Red-team: <tool>
- Comms polish: <tool>
